//
//  main.m
//  RATreeViewBasicExample
//
//  Created by Rafal Augustyniak on 15/11/15.
//  Copyright © 2015 com.Augustyniak. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RAAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RAAppDelegate class]));
    }
}
